This is a messy jumble of utility functions. They were added very organically,
so this directory could use some serious re-organisation.
My apologies.

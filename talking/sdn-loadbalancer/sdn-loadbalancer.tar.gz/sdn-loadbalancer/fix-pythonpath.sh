#!/bin/sh
#!/bin/sh

sed -i "s,/project,$PWD," .env

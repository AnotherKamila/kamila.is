To view the presentation, open `index.html` in a web browser.
